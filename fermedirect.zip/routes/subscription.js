'use strict';
const express   = require('express');
const router    = express.Router();
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');
const crypto    = require('crypto');

const limit = rateLimit({ windowMs: 3600000, max: 10, message: { error: 'Too many subscription attempts.' } });

const buyerRules = [
  body('name').trim().isLength({ min: 2, max: 100 }).escape(),
  body('email').isEmail().normalizeEmail(),
  body('company').trim().isLength({ min: 2, max: 100 }).escape(),
  body('phone').trim().isLength({ min: 6, max: 20 }).escape(),
  body('plan').isIn(['essentiel', 'professionnel', 'entreprise']),
  body('country').trim().isLength({ min: 2, max: 60 }).escape(),
  body('businessType').isIn(['restaurant', 'hotel', 'supermarche', 'distributeur', 'autre']),
];

const farmerRules = [
  body('name').trim().isLength({ min: 2, max: 100 }).escape(),
  body('email').isEmail().normalizeEmail(),
  body('farmName').trim().isLength({ min: 2, max: 100 }).escape(),
  body('phone').trim().isLength({ min: 6, max: 20 }).escape(),
  body('plan').isIn(['partenaire', 'pro-ferme', 'premium-ferme']),
  body('country').trim().isLength({ min: 2, max: 60 }).escape(),
  body('farmSize').isIn(['small', 'medium', 'large']),
];

router.post('/buyer', limit, buyerRules, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ success: false, errors: errors.array().map(e => ({ field: e.path, msg: e.msg })) });
  console.log(`[BUYER] ${req.body.company} | ${req.body.email} | ${req.body.plan}`);
  return res.status(201).json({ success: true, id: crypto.randomUUID(), message: 'Subscription received. We will contact you within 24h.', data: { type: 'buyer', plan: req.body.plan, status: 'pending' } });
});

router.post('/farmer', limit, farmerRules, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ success: false, errors: errors.array().map(e => ({ field: e.path, msg: e.msg })) });
  console.log(`[FARMER] ${req.body.farmName} | ${req.body.email} | ${req.body.plan}`);
  return res.status(201).json({ success: true, id: crypto.randomUUID(), message: 'Demande reçue. Nous vous contactons sous 24h.', data: { type: 'farmer', plan: req.body.plan, status: 'pending' } });
});

router.get('/plans', (req, res) => res.json({
  buyers: [
    { id: 'essentiel',     name: 'Essentiel',     price: 149, currency: 'CAD', period: 'month', volume: '500 kg/mois' },
    { id: 'professionnel', name: 'Professionnel', price: 399, currency: 'CAD', period: 'month', volume: '2 000 kg/mois', popular: true },
    { id: 'entreprise',    name: 'Entreprise',    price: 999, currency: 'CAD', period: 'month', volume: 'Illimité' },
  ],
  farmers: [
    { id: 'partenaire',    name: 'Partenaire',    price: 49,  currency: 'CAD', period: 'month' },
    { id: 'pro-ferme',     name: 'Pro Ferme',     price: 99,  currency: 'CAD', period: 'month', popular: true },
    { id: 'premium-ferme', name: 'Premium Ferme', price: 199, currency: 'CAD', period: 'month' },
  ],
}));

module.exports = router;
